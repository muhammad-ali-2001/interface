
public class CalculateAreas {
    
       
    public static double[] func(GeometricShape[] Figure) {
        
        
        double[] Size = new double[Figure.length];
        
        
        for(int i=0;i<Figure.length;i++) {
            
            if(Figure[i]!=null)
                
                Size[i] = Figure[i].area();
        }
        return Size;
    }
}
