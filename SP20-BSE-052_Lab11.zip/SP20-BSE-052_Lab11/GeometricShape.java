
public interface GeometricShape {
    
    public double area();
}
