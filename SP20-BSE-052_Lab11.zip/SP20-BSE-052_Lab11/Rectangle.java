
public class Rectangle implements GeometricShape{
    
    public double length;
    public double breadth;

    public Rectangle(){

    }

    public Rectangle(double l,double b){
        this.length = l;
        this.breadth = b;
    }

   

    public double area(){
        return length * breadth;
    }


}
