
public class Triangle implements GeometricShape {
        public double base;
    public double height;

    public Triangle(){

    }
    public Triangle(double b, double h){
        this.base = b;
        this.height = h;
    }


    public double area(){
        return 0.5 * base * height;
    }

}
