
public class Circle implements GeometricShape {
        public double radius;


    public Circle(){
    }

    public Circle(double r)
    {
        this.radius = r;
    }

   

    public double area()
    {
        return Math.PI * radius * radius ;
    }

}
