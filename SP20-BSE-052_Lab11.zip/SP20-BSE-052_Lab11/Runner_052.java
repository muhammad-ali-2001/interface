
public class Runner_052 {
         public static void main(String[] args) {
         		//create an object for circle class 
		Circle c = new Circle(4);
                System.out.println("The area of Circle is "+c.area());
//create an object for rectangle class 
		Rectangle r = new Rectangle(4, 3);
		System.out.println("The area of Rectangle is "+r.area());
//create an object for triangle class 
                Triangle t = new Triangle(5, 4);
                System.out.println("The area of Triangle is "+t.area());
//call the method DisplayArea using Circle object
		DisplayArea(c);
                
		//call the method DisplayArea using rectangle object
		DisplayArea(r);
                
                //call the method DisplayArea using triangle object
		DisplayArea(t);
	}
                
         
	public static void DisplayArea(GeometricShape gs)
	{
		double area = gs.area();
		System.out.println("The area of the shape is " + area);
	}
     }

    

